package app.example.victor.streamlive

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class secondActivity : AppCompatActivity() {
    private val web: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val web = findViewById<WebView>(R.id.website)
        web?.webViewClient = WebViewClient()
        web?.loadUrl("https://www.youtube.com/watch?v=wIYC6SEYh2Q")
        val webSettings = web?.settings
        webSettings?.javaScriptEnabled = true

    }

    override fun onBackPressed() {
        if (web!!.canGoBack()) {
            web.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
